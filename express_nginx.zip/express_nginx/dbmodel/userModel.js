var userMode ={
	loginSchema:{
		"name":String,"password":String
	}
}
exports.userMode =userMode;