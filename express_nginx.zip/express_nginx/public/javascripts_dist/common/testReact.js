var testReact =require("@cnpm/testReact");
testReact.testReact();